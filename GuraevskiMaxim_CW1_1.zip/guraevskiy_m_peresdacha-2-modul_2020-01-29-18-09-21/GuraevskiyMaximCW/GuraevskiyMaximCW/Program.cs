﻿using System;
using System.Text;
using System.IO;

/*
 * Гураевский Максим Дмитриевич
 * 1910 -1 
 * 29.01.2020
 */

namespace GuraevskiyMaximCW
{
    class Program
    {

        static Random rnd = new Random();
        static StreamWriter wrt = null;

        /// <summary>
        /// Основное тело программы
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            // Попытка отрытия потока
            try
            {
                wrt = new StreamWriter("../../../PlaneFigure.txt");
            }
            catch(System.Security.SecurityException ex)
            {
                Console.WriteLine($"Не удалось открыть поток на запись по безопастности\r\nВаше сообщение{ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}\r\n{ex.StackTrace}");
            }


            // Повтор решения
            do
            {

                PlaneFigure[] figure = new PlaneFigure[15];

                bool planeFigureIsCorrect = true;

                string newName;
                double aOrRadius;

                // Цикл для создания каждлого объекта
                for (int i = 0; i < 15; i++)
                {


                    // Цикл для повторения создания объекта
                    do
                    {

                        newName = NewName();
                        aOrRadius = rnd.NextDouble() + rnd.Next(4, 13);
                        planeFigureIsCorrect = true;

                        try
                        {
                            if (rnd.Next(1, 3) == 1)
                            {
                                figure[i] = new Circle(aOrRadius, newName);
                            }
                            else
                            {
                                figure[i] = new Square(aOrRadius, newName);
                            }
                        }
                        catch (PlaneFigureException ex)
                        {
                            Console.WriteLine($"{ex.Message}");
                            planeFigureIsCorrect = false;
                        }

                    }
                    while (!planeFigureIsCorrect);

                }

                // Вызов метода для записи в файл и в консоль
                Write(figure);

                // вызов метода ChangePlaneFigure у всех фигур
                foreach (var i in figure)
                {
                    i.ChangePlaneFigure();
                }

                // Вызов метода для записи в файл и в консоль
                Write(figure);



                Console.WriteLine("Для выхода из программы нажмите кнопку Escape, для повтора решения - любую другую кнопку");
            }
            while (Console.ReadKey(true).KeyChar != (char)ConsoleKey.Escape); // Условие выхода из программы

            //Закрытие файла
            try
            {
                wrt.Close();
            }
            catch (EncoderFallbackException ex)
            {
                Console.WriteLine($"{ex.Message}\r\n{ex.StackTrace}");
            }


        }



        /// <summary>
        /// Метод для создания нового имени
        /// </summary>
        /// <returns></returns>
        public static string NewName()
        {
            // length - длина новой строки
            int length = rnd.Next(1,10);
            string newName = string.Empty;
            // Создание строки
            for (int i = 0; i < length; i++)
            {
                if(rnd.Next(1,3) == 1)
                {
                    newName += (char)rnd.Next('a', 'z'+1);
                }
                else
                {
                    newName += (char)rnd.Next('A', 'Z' + 1);
                }
            }

            return newName;
        }


        /// <summary>
        /// Метод для записи в в файл и в консоль 
        /// </summary>
        /// <param name="figure"></param>
        public static void Write(PlaneFigure[] figure)
        {
            string newLine;
            foreach (var i in figure)
            {
                // Форматирование строки
                newLine = String.Format( "{0:f3}" , i.ToString());

                Console.WriteLine(newLine);
                // Попытка записи в файл
                try
                {
                    wrt.WriteLine(newLine, Encoding.GetEncoding(1251));
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Не удалось записать в файл\r\n{ex.Message}");
                }
            }
        }

    }
    /*
     * Альтернативные решения - 
     * стринг для имени можно создавать не посимвольно, а через  StringBuilder
     * использовать класс File и метод AppendAlltext
     * 
     * 
     * 
     * 
     * 
     */
}

