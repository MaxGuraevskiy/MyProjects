﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuraevskiyMaximCW
{
    public class Circle : PlaneFigure
    {


        private double radius;
        public double Radius
        {
            get { return radius; }
            set {
                if (value <= 0)
                {
                    throw new PlaneFigureException("Радиус меньше или равен нулю");
                }
                else
                {
                    radius = value;
                }
            }
        }

        public override double Area
        {
            get { return (Math.PI * Radius * Radius); }
        }

        public override void ChangePlaneFigure()
        {
            do
            {

                Radius = rnd.NextDouble() + (double)rnd.Next(-2, 7);
            }
            while (Radius <= 0);
        }


        public override string ToString()
        {
            return $"{base.ToString()} Circle with radius: {Radius} cm";
        }



        public Circle(double radius, string name) : base(name)
        {
            Radius = radius;
        }

        




    }
}
