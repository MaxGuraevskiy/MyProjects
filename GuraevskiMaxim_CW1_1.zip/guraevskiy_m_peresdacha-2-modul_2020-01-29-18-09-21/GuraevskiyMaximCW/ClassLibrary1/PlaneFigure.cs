﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuraevskiyMaximCW
{
    public abstract class PlaneFigure
    {

        protected static Random rnd = new Random();


        protected string name;
        public string Name
        {
            get { return name; }
        }

        protected double area;
        public abstract double Area { get; }










        public PlaneFigure(string name)
        {

            bool nameIsCorrect = true;

            for (int i = 0; i < name.Length; i++)
            {

                if (!(((char)name[i] >= (char)'a' && (char)name[i] <= (char)'z') || ((char)name[i] >= (char)'A' && (char)name[i] <= (char)'Z')))
                {
                    nameIsCorrect = false;
                }
            }

            if (name.Length > 7 || name.Length < 2)
                nameIsCorrect = false;

            if (!nameIsCorrect)
            {
                throw new PlaneFigureException("Недопустимое имя");
            }

            this.name = name;
        }

        public override string ToString()
        {
            return $"The plane figure name is {Name}; area is {Area} cm^2";
        }


        public abstract void ChangePlaneFigure();







    }
}
