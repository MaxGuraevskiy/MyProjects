﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuraevskiyMaximCW
{
    public class Square : PlaneFigure
    {

        private double a;
        public double A
        {
            get { return a; }
            set {
                if (value <= 0)
                {
                    throw new PlaneFigureException("Сторона квадрата А меньше или равна нулю");
                }
                else
                {
                    a = value;
                }
            }
        }

        public override void ChangePlaneFigure()
        {
            do
            {

                A = rnd.NextDouble() + (double)rnd.Next(-4, 15);
            }
            while (A <= 0);

            
        }

        public override double Area
        {
            get { return (A * A); }
        }




        public Square(double a, string name) : base(name)
        {
            A = a;
        }


        public override string ToString()
        {
            return $"{base.ToString()} Square with side: {A} cm";
        }







    }
}
