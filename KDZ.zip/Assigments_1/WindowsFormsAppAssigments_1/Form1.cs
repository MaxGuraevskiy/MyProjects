﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsAppAssigments_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            do
            {


                textBox1.Clear();
                textBox1.AppendText("Вы попали в удивительную игру.\r\nВам предстоит сразиться с компьютором тремя видами персонажей.\r\nЕсли вы хотите создать героев вручную, то нажмите кнопку 1, иначе - 2");


            }
            while (true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Ну я пытался
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //мне стало лень дальше
        }

        public class TeamFight
        {
            static Form1 form = new Form1();

            static readonly Random rnd = new Random();

            private static Human[] team1 = null;
            private static Human[] team2 = null;

            public static Human[] Team1 { get { return team1; } private set { team1 = value; } }
            public static Human[] Team2 { get { return team2; } private set { team2 = value; } }

            /// <summary>
            /// Рандомный выбор персонажей
            /// </summary>
            public TeamFight()
            {
                PullHumanArrayTeam1();
                PullHumanArrayTeam2Hand();
            }

            /// <summary>
            /// Рандомный выбор персонажей
            /// </summary>
            /// <param name="str"></param>
            public TeamFight(string str)
            {
                PullHumanArrayTeam1();
                PullHumanArrayTeam2();
            }

            /// <summary>
            /// Рандомное заполнение команды компьютера
            /// </summary>
            static void PullHumanArrayTeam1()
            {
                team1 = new Human[10];


                for (int i = 0; i < 10; i++)
                {
                    int rndNext = rnd.Next(0, 100);
                    if (rndNext < 45)
                    {
                        team1[i] = new Fighter();

                    }

                    if ((rndNext < 75) && (rndNext >= 45))
                    {
                        team1[i] = new Ninja();
                    }

                    if ((rndNext >= 75) && (rndNext < 100))
                    {
                        team1[i] = new Samurai();
                    }
                }


            }

            /// <summary>
            /// Рандомное заполнение команды пользователя
            /// </summary>
            static void PullHumanArrayTeam2()
            {
                team2 = new Human[10];


                for (int i = 0; i < 10; i++)
                {
                    int rndNext = rnd.Next(0, 100);
                    if (rndNext < 45)
                    {
                        team2[i] = new Fighter();

                    }

                    if ((rndNext < 75) && (rndNext >= 45))
                    {
                        team2[i] = new Ninja();
                    }

                    if ((rndNext >= 75) && (rndNext < 100))
                    {
                        team2[i] = new Samurai();
                    }
                }

            }

            /// <summary>
            /// Ручной выбор героев для наполнения команды
            /// </summary>
            static void PullHumanArrayTeam2Hand()
            {
                team2 = new Human[10];

                form.textBox1.AppendText("Вы выбрали режим, где сами будете набирать себе отряд бойцов");
                double money;
                // Можно повторно набрать команду, если пользователь передумал
                do
                {

                    form.textBox1.Clear();
                    money = 10;

                    for (int i = 0; money >= 1; i++)
                    {
                        form.textBox1.Clear();

                        form.textBox1.AppendText($"Ваши осташиеся деньги: {money}");


                        form.textBox1.AppendText($"Выберите одного из персонажей\r\n1 - Fighter (стоимость: 1 золотая монета)\r\n2 - Ninja (стоимость: 1,5 золотые монеты)\r\n3 - Samurai (стоимость: 2 золотые монеты)");


                        int selectHero;
                        while (!((int.TryParse(Console.ReadLine(), out selectHero)) && (selectHero >= 1) && (selectHero <= 3))) ;


                        switch (selectHero)
                        {

                            case 1:
                                form.textBox1.AppendText($"Вы уверенны в выборе героя Fighter, как своего {i + 1} героя?");
                                
                                break;

                            case 2:
                                form.textBox1.AppendText($"Вы уверенны в выборе героя Ninja, как своего {i + 1} героя?");
                                
                                break;

                            case 3:
                                form.textBox1.AppendText($"Вы уверенны в выборе героя Samurai, как своего {i + 1} героя?");
                                
                                break;

                        }

                        form.textBox1.AppendText($"Вы уверенны в выборе своего героя? Для того, чтобы сказать 'да' нажмите кнопку Enter,\r\n для того чтобы отказаться от выбора нажмите кнопку Backspace ");

                        char confirmChoice;
                        do
                        {
                            confirmChoice = Console.ReadKey(true).KeyChar;
                        }
                        while ((confirmChoice == (char)ConsoleKey.Escape) || (confirmChoice == (char)ConsoleKey.Backspace));

                        // Выбор нужного героя и подсчёт денег. Поспроизведенна логика, что пользователю не хватает денег на покупку, тогда персонаж не купится
                        switch (confirmChoice)
                        {
                            case (char)ConsoleKey.Enter:

                                switch (selectHero)
                                {
                                    case 1:
                                        if (money >= 1)
                                        {
                                            money -= 1;
                                            team2[i] = new Fighter();
                                            break;
                                        }
                                        else
                                        {
                                            i--;
                                            break;
                                        }
                                    case 2:
                                        if (money >= 1.5)
                                        {
                                            money -= 1.5;
                                            team2[i] = new Ninja();
                                            break;
                                        }
                                        else
                                        {
                                            i--;
                                            break;
                                        }

                                    case 3:
                                        if (money >= 2)
                                        {
                                            money -= 2;
                                            team2[i] = new Samurai();
                                            break;
                                        }
                                        else
                                        {
                                            i--;
                                            break;
                                        }
                                }

                                break;


                            // Если пользователь передумал брать выбранного персонажа, он может не подтвердить свой выбор
                            case (char)ConsoleKey.Backspace:
                                if (i != 0)
                                {
                                    i--;
                                }
                                break;

                        }

                    }

                    form.textBox1.AppendText("Вы уверенны в выборе своей команды? Для того, чтобы сказать 'да' нажмите кнопку Enter,\r\n для того чтобы отказаться от выбора нажмите кнопку Backspace ");
                }
                // Подтвеждение выбора своего боевого отряда
                while (Console.ReadKey(true).KeyChar != (char)ConsoleKey.Enter);

                form.textBox1.AppendText($"У вас кошельке осталось {money} золотых");
            }
            public int Fight(Human[] team1, Human[] team2)
            {
                

                // Нахождение верхнего индекса не нулевой ссылки на объект
                int upperIndexTeam2 = 9;
                for (int i = 0; i < 10; i++)
                {
                    if (team2[i] == null)
                    {
                        upperIndexTeam2 = i - 1;
                        break;
                    }
                }

                // Жива ли первая команда
                bool team1IsAlive = true;
                // Жива ли вторая команда
                bool team2IsAlive = true;
                // Живы ли обе команды
                bool team1AndTeam2IsAlive = true;
                // Рандомное число, чтобы рандомить первый ход
                int rndNumber = rnd.Next(0, 100);

                do
                {

                    /*for (int i = 0; i < 10; i++)
                    {
                        if (team1[i].IsAlive)
                        {
                            team1IsAlive = true;
                            break;
                        }
                        else
                        {
                            team1IsAlive = false;
                            continue;
                        }

                    }
                    for (int i = 0; i < upperIndexTeam2 + 1; i++)
                    {
                        if (team2[i].IsAlive)
                        {
                            team2IsAlive = true;
                            break;
                        }
                        else
                        {
                            team2IsAlive = false;
                            continue;
                        }

                    }*/

                    // Осуществление логики жива ли какая-то команда или нет
                    team1IsAlive = team1.Any(member => member.IsAlive);

                    team2IsAlive = team2.Any(member => member.IsAlive);

                    if (team1IsAlive && team2IsAlive)
                    {
                        team1AndTeam2IsAlive = true;
                    }
                    else
                    {
                        team1AndTeam2IsAlive = false;
                    }

                    // Вывод ответа, какая команда победила
                    if (team1IsAlive && !team2IsAlive)
                    {
                        return 1;
                    }

                    if (team2IsAlive && !team1IsAlive)
                    {
                        return 2;
                    }


                    // Осуществление по очердной атаки одного из бойцов, а так же случайный выбор первого хода
                    if (rndNumber % 2 == 0)
                    {

                        int indexTeam1 = rnd.Next(0, 10);
                        int indexTeam2 = rnd.Next(0, upperIndexTeam2 + 1);

                        for (; team1IsAlive;)
                        {
                            indexTeam1 = rnd.Next(0, 10);
                            if (team1[indexTeam1].IsAlive)
                            {
                                break;
                            }
                        }

                        for (; team2IsAlive;)
                        {
                            indexTeam2 = rnd.Next(0, upperIndexTeam2 + 1);
                            if (team2[indexTeam2].IsAlive)
                            {
                                break;
                            }
                        }

                        // Выбор как атаковать герою и что выводить в консоль, исходя из его подтипа

                        if (team1[indexTeam1] is Ninja)
                        {
                            (team1[indexTeam1] as Ninja).BattleCry();
                            (team1[indexTeam1] as Ninja).Attack(team2[indexTeam2]);

                            if (team2[indexTeam2] is Ninja)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Ninja атаковал Ninja и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Samurai)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Ninja атаковал Samurai и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Fighter)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Ninja атаковал Fighter и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                        }
                        else if (team1[indexTeam1] is Samurai)
                        {
                            (team1[indexTeam1] as Samurai).BattleCry();
                            (team1[indexTeam1] as Samurai).Attack(team2[indexTeam2]);

                            if (team2[indexTeam2] is Ninja)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Samurai атаковал Ninja и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Samurai)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Samurai атаковал Samurai и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Fighter)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Samurai атаковал Fighter и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                        }
                        else if (team1[indexTeam1] is Fighter)
                        {
                            (team1[indexTeam1] as Fighter).BattleCry();
                            (team1[indexTeam1] as Fighter).Attack(team2[indexTeam2]);

                            if (team2[indexTeam2] is Ninja)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Fighter атаковал Ninja и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Samurai)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Fighter атаковал Samurai и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }
                            else if (team2[indexTeam2] is Fighter)
                            {
                                form.textBox1.AppendText($"Из команды противника(комплюктера) Fighter атаковал Fighter и нанёс {(team1[indexTeam1] as Fighter).Damage - (team2[indexTeam2] as Fighter).Guard} урона");
                            }

                        }

                    }
                    else
                    {
                        int indexTeam1 = rnd.Next(0, 10);
                        int indexTeam2 = rnd.Next(0, upperIndexTeam2 + 1);
                        for (; team1IsAlive;)
                        {
                            indexTeam1 = rnd.Next(0, 10);
                            if (team1[indexTeam1].IsAlive)
                            {
                                break;
                            }
                        }

                        for (; team2IsAlive;)
                        {
                            indexTeam2 = rnd.Next(0, upperIndexTeam2 + 1);
                            if (team2[indexTeam2].IsAlive)
                            {
                                break;
                            }
                        }

                        // То же самое, что и выше, только для другой команды
                        if (team2[indexTeam2] is Ninja)
                        {
                            (team2[indexTeam2] as Ninja).BattleCry();
                            (team2[indexTeam2] as Ninja).Attack(team1[indexTeam1]);

                            if (team1[indexTeam1] is Ninja)
                            {
                                form.textBox1.AppendText($"Из вышей команды Ninja атаковал Ninja и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Samurai)
                            {
                                form.textBox1.AppendText($"Из вышей команды Ninja атаковал Samurai и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Fighter)
                            {
                                form.textBox1.AppendText($"Из вашей команды Ninja атаковал Fighter и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                        }
                        else if (team2[indexTeam2] is Samurai)
                        {
                            (team2[indexTeam2] as Samurai).BattleCry();
                            (team2[indexTeam2] as Samurai).Attack(team1[indexTeam1]);

                            if (team1[indexTeam1] is Ninja)
                            {
                                form.textBox1.AppendText($"Из вышей команды Samurai атаковал Ninja и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Samurai)
                            {
                                form.textBox1.AppendText($"Из вышей команды Samurai атаковал Samurai и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Fighter)
                            {
                                form.textBox1.AppendText($"Из вашей команды Samurai атаковал Fighter и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                        }
                        else if (team2[indexTeam2] is Fighter)
                        {
                            (team2[indexTeam2] as Fighter).BattleCry();
                            (team2[indexTeam2] as Fighter).Attack(team1[indexTeam1]);

                            if (team1[indexTeam1] is Ninja)
                            {
                                form.textBox1.AppendText($"Из вышей команды Fighter атаковал Ninja и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Samurai)
                            {
                                form.textBox1.AppendText($"Из вышей команды Fighter атаковал Samurai и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                            else if (team1[indexTeam1] is Fighter)
                            {
                                form.textBox1.AppendText($"Из вашей команды Fighter атаковал Fighter и нанёс {(team2[indexTeam2] as Fighter).Damage - (team1[indexTeam1] as Fighter).Guard} урона");
                            }
                        }

                    }
                    // Чтобы команды менялись местами
                    rndNumber++;
                }
                // Пока обе команды живы, они воюют 
                while (team1AndTeam2IsAlive);

                return 0;
            }


        }



    }

    

}


