﻿using System;
using System.IO;


namespace ClassLibrary1
{
    /// <summary>
    /// Абстрактный класс Логгер, из которого наследуются остальные
    /// </summary>
    public abstract class Logger
    {
        public abstract void Log(string text);
    }

    /// <summary>
    /// Класс ConsoleLogger для логирования в консоль
    /// </summary>
    public class ConsoleLogger : Logger
    {
        public override void Log(string text)
        {
            Console.WriteLine(text);
        }
    }

    /// <summary>
    ///  Класс FileLogger для логгирования в файл
    /// </summary>
    public class FileLogger : ConsoleLogger
    {
        public override void Log(string text)
        {
            File.WriteAllText("log.txt", text);
        }
    }

    //Возможна вариация для WPF/WinForms
}

