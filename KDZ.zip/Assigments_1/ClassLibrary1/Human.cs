﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary1
{
    public abstract class Human
    {
        // Я не знаю, что здесь ещё можно рассказать
        public Logger logCons = new ConsoleLogger();
        public Logger logFile = new FileLogger();
        public static Random rnd = new Random();


        protected bool poisoned;
        public bool Poisoned { get { return poisoned; } protected set { poisoned = value; } }


        protected double healthy;
        public double Healthy { get { return healthy; } protected set { healthy = value; } }

        // Свойство показывающее жив ли герой
        public bool IsAlive
        {
            get {
                return healthy > 0;
            }
        }
    }
}
