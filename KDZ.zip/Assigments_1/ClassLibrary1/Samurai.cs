﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Samurai : Fighter
    {

        protected double retaliation;
        public double Retaliation { get { return retaliation; } protected set { retaliation = value; } }

        // Константы, характеристики персонажей
        const int minHealthy = 70;
        const int maxHealthy = 85;
        const int minDamage = 7;
        const int maxDamage = 12;
        const int minGuard = 4;
        const int maxGuard = 6;
        const double minEvade = 0.3;
        const double maxEvade = 0.5;
        const double minRetaliation = 0.3;
        const double maxRetaliation = 0.5;


        /// <summary>
        /// Конструктор самурая
        /// </summary>
        public Samurai()
        {
            healthy = rnd.Next(minHealthy, maxHealthy + 1);
            damage = rnd.Next(minDamage, maxDamage + 1);
            guard = rnd.Next(minGuard, maxGuard + 1);
            do
            {
                evade = rnd.NextDouble();
            }
            while(evade <= minEvade && evade >= maxEvade);
            do
            {
                retaliation = rnd.NextDouble();
            }
            while (evade <= minRetaliation && evade >= maxRetaliation);
        }

        /// <summary>
        /// Атака наследуется от родительского класса
        /// </summary>
        /// <param name="enemy"></param>
        public override void Attack(Human enemy)
        {
            base.Attack(enemy);
        }

        /// <summary>
        /// Метод BattleCry
        /// </summary>
        public override void BattleCry()
        {

            try
            {
                logCons.Log("Чхуа");
            }
            catch (System.IO.IOException ex)
            {
                logCons.Log($"Похоже у вас вылетела ошибка(\r\nЭто произошло в блоке BattleCry у класса Samurai при выводе слова Чхуа в консоль\r\nСкорее всего у вас не поддерживается русская локализация\r\nВаша ошибка:{ex.Message}");
            }
        }
    }
}
