﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Fighter : Human
    {

        protected int damage;
        protected int guard;
        protected double evade;

        // Константы, характеристики персонажа
        const int minHealthy = 50;
        const int maxHealthy = 70;
        const int minDamage = 5;
        const int maxDamage = 10;
        const int minGuard = 3;
        const int maxGuard = 6;

        // Свойства для некоторых из характеристик
        public int Damage{get{return damage; } protected set{damage = value; } }
        public int Guard { get { return guard; } protected set { guard = value; } }
        public double Evade { get { return evade; } protected set { evade = value; } }

        /// <summary>
        /// 
        /// </summary>
        public Fighter()
        {
            this.healthy = rnd.Next(minHealthy, maxHealthy + 1);
            this.damage = rnd.Next(minDamage, maxDamage + 1);
            this.guard = rnd.Next(minGuard, maxGuard + 1);
            this.evade = 0;
        }

        /// <summary>
        /// Метод Attack, в нём находится вся логика атаки 
        /// </summary>
        /// <param name="enemy"></param>
        virtual public void Attack(Human enemy)
        {

            if((IsAlive) && (Poisoned))
            {
                if (0.07 * healthy > 5)
                {
                    healthy -= 0.07 * healthy;
                }
                else
                {
                    healthy -= 5;
                }

            }

            if ((enemy.IsAlive)&&(IsAlive))
            {
                if ((enemy as Fighter).evade < rnd.NextDouble())
                {

                    // С помощью тернарной конструкции определяю больше ли урон, чем защита противника, если нет, то хп не уменьшается
                    (enemy as Fighter).Healthy -= (damage - (enemy as Fighter).guard) >  0 ? (damage - (enemy as Fighter).guard) : 0;
                    if ((enemy as Fighter).guard > 0)
                    {
                        (enemy as Fighter).guard--;
                    }

                    if((this is Ninja)&&((this as Ninja).Poison > rnd.NextDouble()))
                    {
                        (enemy as Fighter).Poisoned = true;
                    }

                    if((enemy is Samurai) && (enemy as Samurai).Retaliation > rnd.NextDouble())
                    {
                        // Проблема в том, что спецификация задания требует, чтобы контратака происходила именно здесь,
                        // поэтому в консоль не выведится то, что кто-то контратаковал, но я оставил баттлкрай, чтобы
                        // можно было хоть как-то понять, что он контратаковал. По желанию этот баттлкрай можно убрать,
                        // так как соперник тоже может увернуться, хотя не сказано в задании про баттлкрай и контратаку
                        (enemy as Samurai).BattleCry();
                        logCons.Log("Samurai контратаковал");
                        (enemy as Samurai).Attack(this);
                    }
                }
            }
        }

        /// <summary>
        /// Метод BattleCry
        /// </summary>
        virtual public void BattleCry()
        {

            try
            {
                logCons.Log("Хыа");
            }
            catch (System.IO.IOException ex)
            {
                logCons.Log($"Похоже у вас вылетела ошибка(\r\nЭто произошло в блоке BattleCry у класса Fighter при выводе слова Хыа в консоль\r\nСкорее всего у вас не поддерживается русская локализация\r\nВаша ошибка:{ex.Message}");
            }
        }

    }
}
